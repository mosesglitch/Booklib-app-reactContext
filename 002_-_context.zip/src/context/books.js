import { createContext } from 'react';

const BooksContext = createContext();

export default BooksContext;
